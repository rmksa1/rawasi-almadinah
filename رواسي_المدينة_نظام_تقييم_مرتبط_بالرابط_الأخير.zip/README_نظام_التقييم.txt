نظام تقييم العملاء — رواسي المدينة

الموقع الآن يحتوي على نموذج تقييم كامل: اسم + نجوم + تعليق.
التقييمات الجديدة تحفظ بحالة pending ولا تظهر للزوار.
الموافقة تتم من Google Sheets بتغيير status من pending إلى approved.

للتشغيل الفعلي:
1) أنشئ Google Sheet جديدًا باسم: رواسي المدينة - تقييمات العملاء.
2) افتح Extensions > Apps Script.
3) انسخ محتوى GoogleAppsScript_Code.gs والصقه في Code.gs ثم احفظ.
4) Deploy > New deployment > Web app.
5) Execute as: Me.
6) Who has access: Anyone.
7) انسخ Web app URL.
8) افتح index.html وابحث عن REVIEWS_API_URL وضع الرابط بين علامتي الاقتباس.
9) أعد ضغط المجلد وانشر النسخة الجديدة.

الموافقة:
- افتح ورقة Reviews.
- كل تقييم جديد يكون pending.
- غيّر status إلى approved ليظهر في الموقع.
- اتركه pending لعدم نشره.

ملاحظة: لا يتم نشر التقييم تلقائيًا، ولا توجد أسماء أو تقييمات وهمية.
