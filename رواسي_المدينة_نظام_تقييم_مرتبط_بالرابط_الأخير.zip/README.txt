رواسي المدينة - موقع إلكتروني

تمت تهيئة النسخة الحالية لمحركات البحث بإضافة:
- عنوان ووصف SEO
- Open Graph وTwitter metadata
- بيانات منظمة LocalBusiness / ProfessionalService
- robots.txt للسماح لمحركات البحث بالزحف إلى الموقع

ملاحظة: لا يمكن إضافة sitemap.xml بشكل صحيح قبل معرفة رابط الموقع النهائي، لأن Google يتطلب عنوان URL كاملًا للخريطة. بعد نشر الموقع، أضف رابط الموقع النهائي إلى sitemap.xml ثم أرسله عبر Google Search Console.
