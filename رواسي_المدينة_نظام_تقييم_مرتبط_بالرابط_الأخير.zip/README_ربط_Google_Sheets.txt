ربط نظام تقييم العملاء مع Google Sheets — رواسي المدينة

هذه النسخة جاهزة للربط. تحتاج فقط إلى إنشاء Google Sheet ونشر Google Apps Script من حسابك.

1) افتح Google Sheets وأنشئ جدولًا جديدًا باسم:
رواسي المدينة - تقييمات العملاء

2) من داخل الجدول اختر:
Extensions > Apps Script

3) احذف أي كود موجود، ثم افتح الملف GoogleAppsScript_Code.gs الموجود مع الموقع وانسخ محتواه كاملًا إلى Code.gs.

4) اضغط Save.

5) اختر Deploy > New deployment.
ثم اختر Web app.

6) الإعدادات:
Execute as: Me
Who has access: Anyone

ثم اضغط Deploy ووافق على صلاحيات Google إذا طلبها.

7) انسخ Web app URL الذي ينتهي عادةً بـ /exec.

8) في ملف index.html داخل الموقع ابحث عن:
const REVIEWS_API_URL = "";

واستبدلها مثلًا بـ:
const REVIEWS_API_URL = "https://script.google.com/macros/s/XXXXXXXX/exec";

9) احفظ index.html ثم أعد ضغط مجلد الموقع وانشر النسخة الجديدة.

طريقة عمل النظام:
- العميل يرسل الاسم + عدد النجوم + التعليق.
- التقييم يُحفظ في ورقة Reviews بحالة pending.
- أنت تغيّر الحالة إلى approved عندما تريد نشره.
- التقييمات المعتمدة تظهر لجميع زوار الموقع.
- لا يتم إنشاء أو عرض أي تقييمات وهمية.

مهم:
لا تشارك رابط التعديل على Google Sheet مع العملاء. الرابط المستخدم داخل الموقع هو رابط Web App فقط.
