const SHEET_NAME = 'Reviews';
function doGet(e){
  const action=(e.parameter.action||'list').toLowerCase();
  if(action!=='list') return json({ok:false,error:'Unsupported action'});
  const rows=getRows().filter(r=>String(r.status).toLowerCase()==='approved').map(publicRow);
  return json({ok:true,reviews:rows});
}
function doPost(e){
  try{
    let body={};
    if(e && e.postData && e.postData.contents){
      try{ body=JSON.parse(e.postData.contents||'{}'); }catch(ignore){ body=e.parameter||{}; }
    }else{ body=e.parameter||{}; }
    if(body.action!=='submit') return json({ok:false,error:'Unsupported action'});
    const name=String(body.name||'').trim().slice(0,80);
    const rating=Math.max(1,Math.min(5,Number(body.rating||0)));
    const comment=String(body.comment||'').trim().slice(0,600);
    if(!name||!comment||!rating) return json({ok:false,error:'Missing fields'});
    const ss=SpreadsheetApp.getActiveSpreadsheet();
    let sh=ss.getSheetByName(SHEET_NAME);
    if(!sh){sh=ss.insertSheet(SHEET_NAME);sh.appendRow(['timestamp','name','rating','comment','status']);}
    sh.appendRow([new Date(),name,rating,comment,'pending']);
    return json({ok:true});
  }catch(err){return json({ok:false,error:String(err)})}
}
function getRows(){const sh=SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_NAME);if(!sh||sh.getLastRow()<2)return [];const v=sh.getDataRange().getValues();return v.slice(1).map(r=>({timestamp:r[0],name:r[1],rating:r[2],comment:r[3],status:r[4]}));}
function publicRow(r){return {name:r.name,rating:r.rating,comment:r.comment};}
function json(obj){return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);}
